$(document).ready(function(){
    $("p:has(i)").css("color", "#B6B6B6");
});